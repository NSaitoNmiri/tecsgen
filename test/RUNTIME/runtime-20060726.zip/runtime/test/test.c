#include <tecs.h>

tecs_int8 a;
tecs_uint8 b;
tecs_int16 c;
tecs_uint16 d;
tecs_int32 e;
tecs_uint32 f;
tecs_int64 g;
tecs_uint64 h;

tecs_bool i;

tecs_float j;
tecs_double k;

