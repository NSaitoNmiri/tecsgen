/* tecs.h */
#ifndef TECS_H_
#define TECS_H_

#include "tecs_config.h"
#include <tecs/machine.h>
#include <tecs/marshal.h>

#endif  /* ! TECS_H_ */
